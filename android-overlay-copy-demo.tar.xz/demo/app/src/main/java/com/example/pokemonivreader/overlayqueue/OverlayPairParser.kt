package com.example.pokemonivreader.overlayqueue

/** The current PvPoke app export contract is exactly two lines per individual:
 *  Pokémon GO search expression, then nickname. Preserve both verbatim. */
data class OverlayPair(val searchText: String, val nickname: String)

class OverlayPairFormatException(message: String) : IllegalArgumentException(message)

object OverlayPairParser {
    fun parse(text: String): List<OverlayPair> {
        var normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        // A single terminal newline is a line separator, not an empty record.
        if (normalized.endsWith("\n")) normalized = normalized.dropLast(1)
        if (normalized.isEmpty()) throw OverlayPairFormatException("入力が空です。検索式とニックネームを一括コピーしてください。")
        val lines = normalized.split('\n')
        if (lines.size % 2 != 0) {
            throw OverlayPairFormatException("全${lines.size}行です。検索式とニックネームを2行ずつ入力してください（${lines.size}行目を確認）。")
        }
        return buildList(lines.size / 2) {
            for (i in lines.indices step 2) {
                val search = lines[i]
                val nickname = lines[i + 1]
                if (search.isBlank()) throw OverlayPairFormatException("${i + 1}行目の検索式が空です。")
                if (nickname.isBlank()) throw OverlayPairFormatException("${i + 2}行目のニックネームが空です。")
                add(OverlayPair(search, nickname))
            }
        }
    }
}
