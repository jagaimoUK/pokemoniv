plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pokemonivreader"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.pokemonivreader.overlayqueuedemo"
        minSdk = 26
        targetSdk = 32 // Only for the isolated test harness. Integrate into real app targetSdk unchanged.
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
